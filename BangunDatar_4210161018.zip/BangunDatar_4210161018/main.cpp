#include <iostream>
#include "bujurSangkar.h"
using namespace std;

int main()
{
	BujurSangkar bujurSangkar(4);
	cout << bujurSangkar.Luas() << endl;
	cout << bujurSangkar.Keliling() << endl << endl;
	system("pause");
	return 0;
}
