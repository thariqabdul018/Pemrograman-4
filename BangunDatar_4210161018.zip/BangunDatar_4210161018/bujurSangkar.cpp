#include "bujurSangkar.h"

int BujurSangkar::Luas()
{
	return panjangSisi * panjangSisi;
}

int BujurSangkar::Keliling()
{
	return 4 * panjangSisi;
}
