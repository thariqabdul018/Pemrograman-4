#include "BangunDatar.h"

class BujurSangkar : public BangunDatar
{
private:
	int panjangSisi;
public:
	BujurSangkar(int _panjangSisi)
	{
		panjangSisi = _panjangSisi;
	}
	int Luas() override;
	int Keliling() override;
};
