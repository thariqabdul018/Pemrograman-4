#pragma once

class BangunDatar
{
public:
	virtual int Luas() = 0;
	virtual int Keliling() = 0;
};